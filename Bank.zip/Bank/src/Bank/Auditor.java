package Bank;

import java.util.Random;

public class Auditor implements Runnable{
private static Random sleeptime = new Random();
private ABankAccount sharedLocation;
String tname;


	public Auditor(ABankAccount shared, String name) {
		sharedLocation = shared;
		tname = name;
	}
	
	
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				//access bank account for current balance
				//sleep a random amount of time, longer then other threads
			
				sharedLocation.audit(tname);
				Thread.sleep(sleeptime.nextInt(2500-1+1)+1);
				
				Thread.sleep(4000);
				Thread.yield();
			
			}
			catch(Exception e) {
				System.out.print("Exception thrown while auditing account ! " );
			}
		}//end while
	}//end method

}
