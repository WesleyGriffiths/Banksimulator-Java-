package Bank;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ABankAccount implements theBank {
private Lock accessLock = new ReentrantLock();
	private Condition canWithdrawal = accessLock.newCondition();
	
	
	private int balance = 0;
	private static int transactionNumber = 0;
	private static int numberOfTransactionsSinceLastaudit = 0;
	
	private static final int DEPOSIT_ALERT_LEVEL = 350;
	private static final int WITHDRAWAL_ALERT_LEVEL = 75;
	
	public void audit(String name) {
		System.out.print("\n*********************************************************************************************************************\n\n");
		System.out.print(name +" FINDS CURRENT BALANCE TO BE: " + balance + "\t\t Number of transactions since last audit is: " + numberOfTransactionsSinceLastaudit);
		System.out.print("\n\n*********************************************************************************************************************\n\n");
		numberOfTransactionsSinceLastaudit = 0;
	}


	public void flagged_transaction(int value, String thread, String type) {
		// TODO Auto-generated method stub
	Date today = new Date();
	DateFormat dateTime = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.LONG, Locale.FRANCE);
	FileWriter transactionFile;
	PrintWriter PrintWriter = null;
	StringBuilder output = new StringBuilder();
	try {
		transactionFile = new FileWriter("transactions.txt", true);
		PrintWriter = new PrintWriter(transactionFile);
		String timeStamp = dateTime.format(today);
		if(type.equals("D")) {
			output.append("\nDepositor " + thread + " issued deposit of $" + value + ".00 at: " + timeStamp + "\tTransaction Number : " +transactionNumber);
		}
		else {
			output.append("\n\tWithdrawal " + thread + " issued withdrawal of $" + value + ".00 at: " + timeStamp + "\tTransaction Number : " +transactionNumber);
			
		}
		PrintWriter.print(output.toString());
		//end try
	}
	catch(IOException ioException) {
		System.out.println("\nError: Problem writing to transaction file.\n");
	}
	finally {
		PrintWriter.close();
	}
	}
	
	public void deposit ( int depositAmount, String dep) {
		accessLock.lock();
		
		try {
			balance+=depositAmount; //computation for deposit
			transactionNumber++;
			numberOfTransactionsSinceLastaudit++;
			System.out.print(dep+" deposits is $" +depositAmount);
			System.out.println( "\t\t\t\t\t\t(+) Balance is $"+balance+ "\t\t\t\t\t\t\t\t" + transactionNumber);
			
			if(depositAmount>= DEPOSIT_ALERT_LEVEL) {
				System.out.println("\n* * * Flagged Transaction - Depositor " + dep + " Made A Deposit In Excess of $" + DEPOSIT_ALERT_LEVEL + ".00 USD - SEE Flagged Transaction Log.");
				flagged_transaction(depositAmount, dep, "D");
			}
			canWithdrawal.signalAll();
		}
		catch(Exception e) {
			System.out.print("Exception thrown depositing.");
		}
		finally {
			accessLock.unlock();	
		}		
	}

	
	public void withdrawl ( int withdrawalAmount, String wit) {
		accessLock.lock();
		
		try {
			System.out.print("\t\t\t\t\t"+wit+ " withdraws $"+withdrawalAmount);
			if((balance-withdrawalAmount)<0)
			{
				System.out.println("\t\t(****** WITHDRAWAL BLOCKED - INSUFFICIENT FUNDS!!!");
				canWithdrawal.await();
			
			}
			else {
				balance -= withdrawalAmount;
				transactionNumber++;
				numberOfTransactionsSinceLastaudit++;
				System.out.println("\t\t(-) Balance is $" + balance + "\t\t\t\t\t\t\t\t" + transactionNumber);
				
				if(withdrawalAmount>= WITHDRAWAL_ALERT_LEVEL) {
					System.out.println("\n* * * Flagged Transaction - Withdrawal " + wit + " Made A Withdrawal In Excess of $" + WITHDRAWAL_ALERT_LEVEL + ".00 USD - SEE Flagged Transaction Log.");
					flagged_transaction(withdrawalAmount, wit, "W");
				}
				
			}
			
		}
		catch(Exception e) {
			System.out.print("Exception thrown withdrawing.");
		}
		finally {
			accessLock.unlock();	
		}
}

	
	

}

