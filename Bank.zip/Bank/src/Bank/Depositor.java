package Bank;

//import java.io.IOException;
import java.util.Random;



public class Depositor implements Runnable {
private static int max_dep = 500;
private static Random generator = new Random();
private static Random sleeptime = new Random();

private static ABankAccount sharedLocation; //Reference to bank account
	String tname;
	
	
	public Depositor(ABankAccount shared, String name) {
		sharedLocation = shared;
		tname = name;
	}
	
	public void run() {
		//System.out.println("Test: " + tname);
	
	while(true) {
		
		try {
			sharedLocation.deposit(generator.nextInt(max_dep-1+1)+1, tname);
			Thread.sleep(generator.nextInt(3000));
			Thread.sleep(sleeptime.nextInt(3500-1+1)+1);
			Thread.sleep(10);
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
	/*	catch(InterruptedException exception) {
			exception.printStackTrace();
		}*/
	}//end while
	}//end method
}
