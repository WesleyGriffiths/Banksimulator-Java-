package Bank;

import java.util.Random;

public class Withdrawal implements Runnable {
private static int MAX_WITHDRAW = 99;
private static Random generator = new Random();
private static Random sleeptime = new Random();
private ABankAccount sharedLocation;
String tname;

public Withdrawal(ABankAccount shared, String name) {
	sharedLocation = shared;
	tname = name;
}
	
	
	
	
	
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
			sharedLocation.withdrawl(generator.nextInt(MAX_WITHDRAW-1+1)+1,tname);
			Thread.sleep(sleeptime.nextInt(140-1+1)+1);
			Thread.sleep(1000);
			Thread.yield();
		}
		catch(Exception exception) {
			System.out.print("Exception thrown withdrawing !");
			exception.printStackTrace();
		}
			/*catch(InterruptedException exception) {
				exception.printStackTrace();
			}*/
		}//end while
	}

}
