package Bank;

public abstract interface theBank {

	//inputs are deposit amount, thread name
	public abstract void deposit(int depositAmount, String dep);
	
	
	//inputs are withdrawal amount, thread name
	public abstract void withdrawl(int withdrawalAmount, String wit);
	
	//inputs are transaction amount, thread name, thread type
	public abstract void flagged_transaction(int value, String thread, String type);
	
	public abstract void audit(String name);
}
