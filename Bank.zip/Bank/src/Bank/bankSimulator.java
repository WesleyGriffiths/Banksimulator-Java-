package Bank;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class bankSimulator {
public static final int MAX = 16;
	
	public static void main(String[] args) {
	
		ExecutorService application = Executors.newFixedThreadPool(MAX);
System.out.println("Deposit Agents\t\t\t\tWithdrawal Agents\t\tBalance\t\t\t\t\t\t\t\tTransaction Number");
System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------");
ABankAccount sharedLocation = new ABankAccount();
	try {
		application.execute(new Withdrawal(sharedLocation, "Agent WT0"));
		application.execute( new Depositor(sharedLocation,"Agent DT0"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT9"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT5"));
		application.execute( new Depositor(sharedLocation,"Agent DT4"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT4"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT6"));
		application.execute( new Depositor(sharedLocation,"Agent DT3"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT1"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT7"));
		application.execute( new Depositor(sharedLocation,"Agent DT1"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT8"));
		application.execute( new Depositor(sharedLocation,"Agent DT2"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT2"));
		application.execute(new Withdrawal(sharedLocation, "Agent WT3"));
		application.execute(new Auditor(sharedLocation, "AUDITOR"));
		
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	
	application.shutdown();
	
	
	}
}
