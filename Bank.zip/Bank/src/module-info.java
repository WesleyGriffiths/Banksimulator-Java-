/**
 * 
 */
/**
 * @author nojow
 *
 */
module Bank {
}